================================================================================
  Ramanujan telescopic decomposition — GUI (Publication 5, Windows ZIP)
================================================================================

ENGLISH
-------
1. Install Python 3.9 or newer from https://www.python.org/
   (enable "Add python.exe to PATH" during setup).
2. Open Command Prompt in this folder and run:
      pip install sympy
   (Tkinter is included with Python on Windows.)
3. Start the GUI:
      Double-click Run_GUI_EN.bat   (English UI)
   or Double-click Run_GUI_RU.bat   (Russian UI)
   or:  py -3 decompose_gui_EN.py
        py -3 decompose_gui.py

Files: clear_result.py (engine), decompose_gui_EN.py, decompose_gui.py


РУССКИЙ
-------
1. Установите Python 3.9+ с https://www.python.org/
   (в установщике включите добавление Python в PATH).
2. В командной строке в этой папке выполните:
      pip install sympy
   (Tkinter обычно уже входит в состав Python для Windows.)
3. Запуск:
      Двойной щелчок Run_GUI_RU.bat  (интерфейс на русском)
   или Run_GUI_EN.bat  (интерфейс на английском)
   или:  py -3 decompose_gui.py

Файлы: clear_result.py (логика), decompose_gui.py, decompose_gui_EN.py

================================================================================
