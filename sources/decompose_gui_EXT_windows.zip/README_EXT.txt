================================================================================
  Ramanujan telescopic decomposition — GUI + parametric form (Publication 6, Windows ZIP)
================================================================================

Same engine as publication 5 (clear_result.py), plus:
  • «Parametric form» — quadratics in x for b₀ = 10ⁿ−1 (internal scales 10⁷−1, 10⁶−1, 10⁵−1),
    invariant P(x), checks on Σ S, Σ S², Σ S³.
  • Optional auto-append after «Compute» when eligible.

ENGLISH
-------
1. Python 3.9+ from https://www.python.org/ (add to PATH).
2. In this folder:  pip install sympy
3. Start:
      Double-click Run_GUI_EXT_EN.bat   (English)
   or Double-click Run_GUI_EXT_RU.bat   (Russian)
   or:  py -3 decompose_gui_EXT_EN.py
        py -3 decompose_gui_EXT.py

Files: clear_result.py, decompose_gui_EXT_EN.py, decompose_gui_EXT.py


РУССКИЙ
-------
1. Python 3.9+ с https://www.python.org/ (в PATH).
2. В этой папке:  pip install sympy
3. Запуск:
      Run_GUI_EXT_RU.bat  (русский)
   или Run_GUI_EXT_EN.bat  (английский)
   или:  py -3 decompose_gui_EXT.py

Файлы: clear_result.py, decompose_gui_EXT.py, decompose_gui_EXT_EN.py

================================================================================
