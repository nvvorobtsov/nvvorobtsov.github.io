@echo off
cd /d "%~dp0"

py -3 -c "import sys; import tkinter; import sympy; assert sys.version_info[:2]>=(3,9)" 2>nul
if errorlevel 1 goto tryregular
py -3 "%~dp0decompose_gui_EXT.py"
goto eof

:tryregular
python -c "import sys; import tkinter; import sympy; assert sys.version_info[:2]>=(3,9)" 2>nul
if errorlevel 1 goto badenv
python "%~dp0decompose_gui_EXT.py"
goto eof

:badenv
msg * "Need Python 3.9+ with Tkinter and SymPy. Install Python from python.org (Add to PATH), then: pip install sympy"
exit /b 1

:eof
